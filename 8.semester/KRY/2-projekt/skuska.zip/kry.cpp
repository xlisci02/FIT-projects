#include<iostream>
using namespace std;
#include <gmp.h>
#include <gmpxx.h>
#include <math.h>

#define K 100

bool miller_rabin_test(mpz_t n, gmp_randstate_t state){
    bool can_be_prime;
    mpz_t d,r;
    mpz_inits(d,r, NULL);
    mpz_sub_ui(d, n, 1);
    do{
        mpz_div_ui(d, d, 2);
        mpz_add_ui(r,r,1);
    }
    while(mpz_even_p(d));
    // return true;
    // cout << r << " " << d << endl;
    mpz_t a, x, nminus3, nminus1, copy_r;
    mpz_inits(a,x, nminus1, nminus3, copy_r, NULL);
    mpz_sub_ui(nminus3, n, 3);
    mpz_sub_ui(nminus1, n, 1);
    for(int i = 0; i < K; i++){
        can_be_prime = false;
        // random number from interval <2;n-2>
        mpz_urandomm(a, state, nminus3);
        mpz_add_ui(a, a, 2);
        mpz_powm(x, a, d, n);
        if (mpz_cmp_ui(x, 1) == 0 || mpz_cmp(x, nminus1) == 0 )
            continue;
        mpz_set(copy_r, r);
        while(mpz_cmp_ui(copy_r, 1) != 0){
            // cout << x << endl;
            mpz_powm_ui(x,x,2,n);
            // cout << x << endl;
            if(mpz_cmp(x, nminus1) == 0)
                can_be_prime = true;
            mpz_sub_ui(copy_r, copy_r, 1);
            // cout << "este v cykle, can_be_prime = " << can_be_prime << endl;
        }
        // cout << "pred, can_be_prime = " << can_be_prime << endl;
        if(!can_be_prime){
            // cout << "vraciam false, can_be_prime = " << can_be_prime << endl;
            return false;

        }
    }
    // cout << "vraciam true" << endl;
    return true;
}

// https://www.geeksforgeeks.org/program-find-hcf-iteratively/
void gcd1(mpz_t gcd_of_ab, mpz_t a, mpz_t b){
    if(mpz_cmp(a,b) == 0 || (mpz_cmp_ui(b,0) == 0)){
        mpz_set(gcd_of_ab, a);
    }
    else if(mpz_cmp_ui(a,0) == 0){
        mpz_set(gcd_of_ab, b);
    }else{
        // aa and bb are copies of a and b
        mpz_t aa, bb;
        mpz_init_set(aa, a);
        mpz_init_set(bb, b);
        int i = 0;
        while (mpz_cmp(aa,bb) != 0)
        {
            // cout << "helo" << i++ << endl;
            if (mpz_cmp(aa,bb) > 0)
                mpz_sub(aa, aa, bb);
                // a = a - b;
            else
                mpz_sub(bb, bb, aa);
                // b = b - a;
            cout << "a: " << aa << " b: " << bb << endl;
        }
        cout << "idem prec" << (mpz_cmp_ui(a,1) == 0) << endl;
        mpz_set(gcd_of_ab, aa);
    }
}

void gcd2(mpz_t gcd_of_ab, mpz_t a, mpz_t b){

    mpz_t t;
    mpz_init(t);
    mpz_t aa, bb;
    mpz_init_set(aa, a);
    mpz_init_set(bb, b);
    while (mpz_cmp_ui(bb, 0) != 0){
    // cout  << t << " "<< aa << " " << bb << endl;
        mpz_set(t,bb);
        // t = b;
        mpz_mod(bb,aa,bb);
        mpz_set(aa,t);
        // b = a mod b;
        // a = t;
    }
    mpz_set(gcd_of_ab, aa);
    // cout << "gcd is" << aa << endl;
}


bool gcd_is1(mpz_t a, mpz_t b){
    mpz_t gcd_of_ab;
    mpz_init(gcd_of_ab);
    gcd2(gcd_of_ab, a, b);
    bool res = (mpz_cmp_ui(gcd_of_ab,1) == 0);
    // TODO clear memory
    return res;
}

void get_prime_num(mpz_t number, mp_bitcnt_t bit_range, gmp_randstate_t state){
    do{
        do{
            mpz_urandomb(number, state, bit_range);
            // cout << number << endl;
        }while(mpz_cmp_ui(number, 3) <= 0);

    }while(!miller_rabin_test(number, state));
}

void get_public_key(mpz_t key, mpz_t phi_n, gmp_randstate_t state){
    cout << "-" << endl;
    do{
        cout << "--" << endl;
        mpz_urandomm(key, state, phi_n);
        // cout << "key: " << key << endl;
        // if((mpz_cmp_ui(key, 3) <= 0)){
        //     cout << "mansie ako 3: " << (mpz_cmp_ui(key, 3) <= 0) << endl;
        //     continue;
        // }
        // cout << "nema gcd 1: " << !gcd_is1(key, phi_n) << endl;
        // cout << "nieje prvocislo: " << !miller_rabin_test(key, state) << endl;
    }while((mpz_cmp_ui(key, 3) <= 0) || !gcd_is1(key, phi_n) || !miller_rabin_test(key, state));

}

void extended_euclidean_algorithm(mpz_t a, mpz_t b, mpz_t x){
    mpz_t aa, bb, y,u,v,q,tmp,m,n,r;
    // aa and bb are copies of a and b
    mpz_inits(x,v,q,tmp,m,n,r, NULL);
    mpz_init_set(aa, a);
    mpz_init_set(bb, b);
    mpz_init_set_ui(u,1);
    mpz_init_set_ui(y,1);
    while(mpz_cmp_ui(aa, 0) != 0){
        mpz_div(q,bb,aa); // q = b/a
        mpz_mod(r,bb,aa); // r = b%a

        mpz_mul(tmp,u,q); // tmp = u*q
        mpz_sub(m, x, tmp); // m = x - u*q
        mpz_mul(tmp,v,q); // tmp = v*q
        mpz_sub(n, y, tmp); // n = y - v*q

        mpz_set(bb,aa);
        mpz_set(aa,r);
        mpz_set(x,u);
        mpz_set(y,v);
        mpz_set(u,m);
        mpz_set(v,n);
    }
}
// def egcd(a, b):
//     x,y, u,v = 0,1, 1,0 // maame
//     while a != 0:
//         q, r = b/a, b%a
//         m, n = x-u*q, y-v*q
//         b,a, x,y, u,v = a,r, u,v, m,n
//     gcd = b
//     return gcd, x, y

void eulers_totient(mpz_t phi_n, mpz_t p, mpz_t q){
    mpz_t pminus1,qminus1;
    mpz_inits(pminus1,qminus1, NULL);
    mpz_sub_ui(pminus1, p, 1);
    mpz_sub_ui(qminus1, q, 1);
    mpz_mul(phi_n, pminus1, qminus1);
}

void encrypt(mpz_t cipher, mpz_t message, mpz_t e, mpz_t n){
    mpz_powm(cipher,message,e,n);
}

void decrypt(mpz_t message, mpz_t cipher, mpz_t d, mpz_t n){
    mpz_powm(message,cipher,d,n);
}

void generate_keys(mpz_t public_key, mpz_t private_key, mp_bitcnt_t bit_range_for_n, gmp_randstate_t state){
    mpz_t p,q,n,phi_n;
    mpz_inits(n,p,q,phi_n,public_key, private_key, NULL);

    mp_bitcnt_t bit_range_for_pq = bit_range_for_n/2;
    get_prime_num(p, bit_range_for_pq, state); // p
    get_prime_num(q, bit_range_for_pq, state); // q
    mpz_mul(n,p,q); // n = p * q
    eulers_totient(phi_n,p,q); // phi_n = (p-1) * (q-1)
    get_public_key(public_key, phi_n, state); // public key
    // cout << "NEW" << endl;
    // cout << "q: " << p << endl;
    // cout << "p: " << q << endl;
    // cout << "n: " << n << endl;
    // cout << "phi_n: " << phi_n << endl;
    // cout << "public key: " << public_key  << endl;
    mpz_set_ui(public_key,7);
    mpz_set_ui(phi_n,120);
    mpz_set_ui(n, 143);

    // private key
    extended_euclidean_algorithm(public_key, phi_n, private_key); // inverse public key
    mpz_mod(private_key, private_key, phi_n); // inverse public key mod phi_n = private key
    // cout << "new private key " <<  private_key << endl;
    mpz_t message, cipher;
    mpz_init(cipher);
    mpz_init_set_ui(message,9);
    encrypt(cipher, message, public_key, n);
    // cout << "sifra: " << cipher << endl;
    decrypt(message,cipher,private_key, n);
    // cout << "rozsifrovana sprava: " << message << endl;

}


// PO STAROM, podla WIKIPEDIE, POMALE !
// y = (x^2 + 1) mod n
void g(mpz_t y, mpz_t x, mpz_t n){
    mpz_t xpow2;
    mpz_init(xpow2);
    mpz_pow_ui(xpow2,x,2); // x^2
    mpz_add_ui(xpow2,xpow2, 1); // x^2 + 1
    mpz_mod(y, xpow2, n); // (x^2 + 1) mod n
}

void pollard_rho(mpz_t result, mpz_t n){

    cout << "blablabla" << endl;
    mpz_t x,y,d, abs_diff;
    mpz_init(abs_diff);
    mpz_init_set_ui(x, 2);
    mpz_init_set_ui(y, 2);
    mpz_init_set_ui(d, 1);
    while(mpz_cmp_ui(d,1) == 0){
        // x = g(x)
        g(x, x, n);
        // y = g(g(y))
        g(y, y, n);
        g(y, y, n);

        // d = gcd(|x - y|, n)
        mpz_sub(abs_diff, x,y);
        mpz_abs(abs_diff, abs_diff);
        gcd2(d, abs_diff, n);
    }
    if(mpz_cmp(d,n) == 0)
        return; // error
    else
        mpz_set(result, d);
    return;
}
    // while d = 1:
    //     x ← g(x)
    //     y ← g(g(y))
    //     d ← gcd(|x - y|, n)

    // if d = n:
    //     return failure
    // else:
    //     return d



// }
long long int modular_pow(long long int base, int exponent,
                          long long int modulus)
{
    /* initialize result */
    long long int result = 1;

    while (exponent > 0)
    {
        /* if y is odd, multiply base with result */
        if (exponent & 1)
            result = (result * base) % modulus;

        /* exponent = exponent/2 */
        exponent = exponent >> 1;

        /* base = base * base */
        base = (base * base) % modulus;
    }
    return result;
}

// po NOVOM podlal geeks for geeks !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
void pollard_rho_geeks(mpz_t result, mpz_t n, gmp_randstate_t state){
    // cout << "n: " << n << endl;
    mpz_t tmp;
    mpz_init(tmp);
    if(mpz_cmp_ui(n,1) == 0) // n=1
        mpz_set(result, n);
    if(mpz_even_p(n)) // n is even
        mpz_set_ui(result, 2);
    // generate from range <2,n) and store it to x and y
    mpz_t nminus1, nminus2, x, y;
    mpz_inits(nminus1, nminus2, x, NULL);
    mpz_sub_ui(nminus2, n, 2);
    mpz_urandomm(x, state, nminus2);
    mpz_add_ui(x,x,2);
    mpz_init_set(y,x);

    // generate from range <1,n) and store it to c
    mpz_t c;
    mpz_init(c);
    mpz_sub_ui(nminus1, n, 1);
    mpz_urandomm(c, state, nminus1);
    mpz_add_ui(c,c,1);
    // return;

    mpz_t d;
    mpz_init_set_ui(d, 1);

    mpz_t abs_diff;
    mpz_init(abs_diff);
    while(mpz_cmp_ui(d,1) == 0){
        // Tortoise move
        mpz_powm_ui(x, x,2,n);  //  x^2
        mpz_add(x, x, c); // x^2+c
        mpz_add(x, x, n); // x^2+c+n
        mpz_mod(x, x, n);  // (x^2+c+n) % n
        // cout << "x: " << x << endl;
        // Hare move
        mpz_powm_ui(y,y,2,n);  //  y^2
        mpz_add(y, y, c); // y^2+c
        mpz_add(y, y, n); // y^2+c+n
        mpz_mod(y, y, n); // (y^2+c+n) % n
        mpz_powm_ui(y, y,2,n);  //  y^2
        mpz_add(y, y, c); // y^2+c
        mpz_add(y, y, n); // y^2+c+n
        mpz_mod(y, y, n);  // (y^2+c+n) % n
        // cout << "y: " << y << endl;


        mpz_sub(abs_diff, x, y); // x-y
        mpz_abs(abs_diff, abs_diff); // |x-y|
        gcd2(d,abs_diff,n);
        if(mpz_cmp(d,n) == 0)
        // {
        //     // generate new x and c
        //     mpz_urandomm(x, state, nminus2);
        //     mpz_add_ui(x,x,2);
        //     mpz_set(y,x);
        //     mpz_urandomm(c, state, nminus1);
        //     mpz_add_ui(c,c,1);
        //     mpz_set_ui(d, 1);
        // }
            pollard_rho_geeks(result, n, state);
        // cout << "i am here" << endl;
    }
    // cout << "halabal" << endl;
    mpz_set(result, d);
}

/* method to return prime divisor for n */
long long int PollardRho(long long int n)
{
    /* initialize random seed */
    srand (time(NULL));

    /* no prime divisor for 1 */
    if (n==1) return n;

    /* even number means one of the divisors is 2 */
    if (n % 2 == 0) return 2;

    /* we will pick from the range [2, N) */
    long long int x = (rand()%(n-2))+2;
    long long int y = x;

    /* the constant in f(x).
     * Algorithm can be re-run with a different c
     * if it throws failure for a composite. */
    long long int c = (rand()%(n-1))+1;

    /* Initialize candidate divisor (or result) */
    long long int d = 1;

    /* until the prime factor isn't obtained.
       If n is prime, return n */
    while (d==1)
    {
        /* Tortoise Move: x(i+1) = f(x(i)) */
        x = (modular_pow(x, 2, n) + c + n)%n;

        /* Hare Move: y(i+1) = f(f(y(i))) */
        y = (modular_pow(y, 2, n) + c + n)%n;
        y = (modular_pow(y, 2, n) + c + n)%n;

        /* check gcd of |x-y| and n */
        d = __gcd(abs(x-y), n);

        /* retry if the algorithm fails to find prime factor
         * with chosen x and c */
        if (d==n) return PollardRho(n);
    }

    return d;
}

// podla WIKIPEDIE bez kniznice
long long int gcd11(long long int a, long long int b){
    while (a != b)
    {
        if (a > b)
            a = a - b;
        else
            b = b - a;
    }
    return a;
}

long long int g1(long long int x, long long int n){
    return (x*x+1)%n;
}

long long int Polar(long long n){
    long long int x = 2;
    long long int y = 2;
    long long int d = 1;

    while (d==1)
    {
        x = g1(x,n);
        y = g1(g1(y,n),n);
        d = gcd11(llabs(x-y),n);
    }

    if(d == n)
        return 0;
    else
        return d;

    // x ← 2
    // y ← 2
    // d ← 1

    // while d = 1:
    //     x ← g(x)
    //     y ← g(g(y))
    //     d ← gcd(|x - y|, n)

    // if d = n:
    //     return failure
    // else:
    //     return d
}

int main(int argc, char ** argv){
    gmp_randstate_t state;
    gmp_randinit_default(state);
    gmp_randseed_ui(state, time(NULL));

    // generovanie klucov
    mp_bitcnt_t bit_range_for_n = 8; // zo vstupu
    mpz_t public_key, private_key;
    // generate_keys(public_key, private_key, bit_range_for_n, state);

    mpz_t result, n, n1, n2;
    mpz_inits(result, n1, n2, NULL);
    mpz_init_set_ui(n, 805101);

    // pollard_rho(result, n);
    // cout << result << endl;

    // long long int a = PollardRho(144935199964015507);
    // long long int b = 144935199964015507 / a;
    // cout << a << endl << b << endl << 144935199964015507 << endl;
    // cout << "wikipedia " << Polar(76568213399)<< endl;

    // get_prime_num(n1, 48, state);
    // get_prime_num(n2, 48, state);
    // cout << n1 << ' ' << n2 << endl;
    mpz_set_ui(n1,52053910610909);
    mpz_set_ui(n2,224053278157831);
    // void get_prime_num(mpz_t number, mp_bitcnt_t bit_range, gmp_randstate_t state){
    mpz_mul(n, n1, n2);
    cout << n << endl;


    // mpz_set_ui(n,35932881761011812634779963457);
    pollard_rho_geeks(n1, n, state);
    cout << "new approach: " << n1 << endl;


    // cout << "orig: " << PollardRho(35) << endl;

    // pollard_rho(result, n);
    // cout << result << endl;

    // ORIGINAL
    // mpz_t n,p,q,phi_n,pk;
    // mpz_inits(n,p,q,phi_n,pk, NULL);
    // // mpz_set_ui(n, 113);
    // // mpz_set_ui(n, 5);
    // gmp_randstate_t state;
    // gmp_randinit_default(state);
    // gmp_randseed_ui(state, time(NULL));

    // // cout << miller_rabin_test(n, state) << endl;
    // mp_bitcnt_t bit_range_for_n = 8;
    // mp_bitcnt_t bit_range_for_pq = bit_range_for_n/2;
    // get_prime_num(p, bit_range_for_pq, state);
    // get_prime_num(q, bit_range_for_pq, state);
    // mpz_mul(n,p,q);
    // eulers_totient(phi_n,p,q);
    // cout << "q: " << p << endl;
    // cout << "p: " << q << endl;
    // cout << "phi_n: " << phi_n << endl;
    // // miller_rabin_test(n, state);
    // get_public_key(pk, phi_n, state);
    // cout << pk << endl;
    // // mpz_set_ui(p,35);
    // // mpz_set_ui(q,15);
    // mpz_set_ui(pk,7);
    // mpz_set_ui(phi_n,120);
    // mpz_set_ui(n, 143);
    // mpz_t inverse_sk, sk, copy_phi_n, copy_pk;
    // mpz_init(sk);
    // mpz_init_set(copy_phi_n, phi_n);
    // mpz_init_set(copy_pk, pk);
    // extended_euclidean_algorithm(pk,phi_n,inverse_sk);
    // mpz_mod(sk, inverse_sk, phi_n);
    // cout << sk << endl;
    // mpz_t message, cipher;
    // mpz_init(cipher);
    // mpz_init_set_ui(message,9);
    // cout << "pk: " << pk << " n: " << n << endl;
    // encrypt(cipher, message, pk, n);
    // cout << "sifra: " << cipher << endl;
    // decrypt(message,cipher,sk, n);
    // cout << "rozsifrovana sprava: " << message << endl;
    // mpz_t public_key, private_key;
    // generate_keys(public_key, private_key, bit_range_for_n, state);

}